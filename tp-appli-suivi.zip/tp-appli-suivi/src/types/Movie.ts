export interface Movie {
  id: number;
  title: string;
  category: string;
  image: string;
}
