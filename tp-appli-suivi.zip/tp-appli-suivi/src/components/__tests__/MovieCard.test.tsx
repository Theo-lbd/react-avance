import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import MovieCard from '../MovieCard';
import { OmdbMovie } from '../../types/Movie';

describe('MovieCard', () => {
  const movie: OmdbMovie = {
    Title: 'Interstellar',
    Year: '2014',
    imdbID: 'tt0816692',
    Type: 'movie',
    Poster: 'https://image.tmdb.org/t/p/w500/interstellar.jpg',
  };

  beforeEach(() => {
    // 🧪 mock propre du localStorage avant chaque test
    Storage.prototype.getItem = jest.fn(() => '[]');
    Storage.prototype.setItem = jest.fn();
  });

  test('affiche le titre, l\'année et le type du film', () => {
    render(
      <MemoryRouter>
        <MovieCard movie={movie} />
      </MemoryRouter>
    );

    expect(screen.getByText('Interstellar')).toBeInTheDocument();
    expect(screen.getByText(/2014/)).toBeInTheDocument();
    expect(screen.getByText(/movie/)).toBeInTheDocument();
  });

  test('bouton favori fonctionne (ajout)', () => {
    render(
      <MemoryRouter>
        <MovieCard movie={movie} />
      </MemoryRouter>
    );

    const button = screen.getByRole('button', { name: /ajouter aux favoris/i });
    fireEvent.click(button);

    //  Vérifie que setItem a bien été appelée
    expect(localStorage.setItem).toHaveBeenCalled();
  });
});
